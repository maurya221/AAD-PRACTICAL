document.getElementById('matrixForm').addEventListener('submit', function (event) {
    event.preventDefault();
    const dimensions = document.getElementById('dimensions').value;

    fetch('/calculate', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ dimensions }),
    })
    .then(response => response.json())
    .then(data => {
        const resultDiv = document.getElementById('result');
        resultDiv.innerHTML = `<strong>Minimum Multiplications:</strong> ${data.min_multiplications} <br>
                               <strong>Optimal Parenthesization:</strong> ${data.parenthesization}`;
    })
    .catch(error => console.error('Error:', error));
});
